# 🚀 Zeta Proposer - Schnellstart

## Installation (2 Minuten)

### 1. Download & Entpacken

- Laden Sie `Zeta_Proposer.exe` herunter
- Erstellen Sie einen neuen Ordner für das Programm
- Kopieren Sie alle Dateien in diesen Ordner

### 2. OpenAI API Key einrichten

Erstellen Sie eine `.env` Datei im Programmordner:

```
OPENAI_API_KEY=sk-your-openai-api-key-here
```

### 3. Graphviz installieren (optional, für Diagramme)

- Download: https://graphviz.org/download/
- Installation mit Standardeinstellungen
- `dot` muss im System-PATH verfügbar sein

### 4. Programm starten

- Doppelklick auf `Zeta_Proposer.exe`
- Keine weitere Installation erforderlich!

## 📁 Ordnerstruktur

```
Zeta_Proposer/
├── Zeta_Proposer.exe          # Hauptprogramm
├── .env                       # OpenAI API Key (selbst erstellen)
├── README.md                  # Detaillierte Anleitung
├── section_descriptions.json  # Sektionen-Konfiguration
├── logging_config.json        # Logging-Einstellungen
├── env_example.txt           # Beispiel .env Datei
└── templates/                # Word-Templates
    └── Scriptum_Zeta_Project_Proposal_Template.docx
```

## ⚡ Erste Schritte

1. **Projektname eingeben**: Geben Sie einen aussagekräftigen Namen ein
2. **Beschreibung**: Beschreiben Sie Ihr Projekt detailliert
3. **Provider wählen**: OpenAI GPT-4 (empfohlen)
4. **Generieren**: Klicken Sie auf "Generate Concept"

## 📤 Ausgabe

Generierte Dateien finden Sie im `output/` Ordner:

- Word-Dokumente: `output/docx/`
- Diagramme: `output/diagrams/`
- Logs: `output/logs/`

## 🆘 Hilfe

- Lesen Sie `README.md` für detaillierte Anleitung
- Log-Dateien in `output/logs/` für Fehlerdiagnose
- GitHub Issues für Support

---

**Viel Erfolg mit Zeta Proposer! 🎉**
